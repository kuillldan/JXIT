package main;

public class ColumnInfo {
	
	int id;
	String colName;
	String type;
	int len;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getColName() {
		return colName;
	}
	public void setColName(String colName) {
		this.colName = colName;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getLenth() {
		return len;
	}
	public void setLenth(int lenth) {
		this.len = lenth;
	}

}
