package main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.ResourceBundle;
import java.util.Set;

import com.tandem.t4jdbc.SQLMXDataSource;

public class InsertDataMain {

	public static void main(String[] args) {
		ResourceBundle resource = ResourceBundle.getBundle("t4jdbc");
		Connection conn = null;
		try {
			SQLMXDataSource ds = new SQLMXDataSource();
			ds.setUrl(resource.getString("jdbc.url"));
			ds.setCatalog(resource.getString("jdbc.catalog"));
			ds.setSchema(resource.getString("jdbc.schema"));
			ds.setUser(resource.getString("jdbc.username"));
			ds.setPassword(resource.getString("jdbc.password"));
			conn = ds.getConnection(); 
		} catch (Exception e) {
			e.printStackTrace();
		}
//		
//			Class.forName(resource.getString("jdbc.driver"));
//			conn = DriverManager.getConnection(resource.getString("jdbc.url"), resource.getString("jdbc.username"),
//					resource.getString("jdbc.password"));
//		} catch (ClassNotFoundException e) {
//			e.printStackTrace();
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}
//		
		int maxsql = Integer.valueOf(ResourceBundle.getBundle("insert").getString("table.maxsql"));
		
		String[] tables = ResourceBundle.getBundle("insert").getString("table.index").split(",");
		
		boolean truncate = Boolean.valueOf(ResourceBundle.getBundle("insert").getString("table.truncate")).booleanValue();
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			StringBuffer sql = null;
			for(String table:tables){
				if(truncate){
					sql = new StringBuffer();
					sql.append("delete from " + table + ";");
					ps = conn.prepareStatement(sql.toString());
					ps.executeUpdate();
				}
			}
//			conn.setAutoCommit(false);
			for(String table:tables){
//				if(truncate){
//					sql = new StringBuffer();
//					sql.append("PURGEDATA " + table + ";");
//					ps = conn.prepareStatement(sql.toString());
//					ps.executeUpdate();
//				}
				
				int maxcol = Integer.valueOf(ResourceBundle.getBundle("insert").getString("table.maxcolumn."+table));
				
				Set<Integer> col_number = new HashSet<Integer>();
				for(String s: ResourceBundle.getBundle("insert").getString("table.incre."+table).split(",")){
					col_number.add(Integer.valueOf(s));
				}
				
				int tmaxsql = Integer.valueOf(ResourceBundle.getBundle("insert").getString("table.maxsql."+table));
				
				for(int i=1;i<=maxsql;i++){
					if(tmaxsql>0&&i>tmaxsql)
						break;
					if (sql != null) {
						sql = new StringBuffer();
						
						
						sql.append("INSERT INTO " + table);
						sql.append(" VALUES (");
						
					
						
						for(int n=1;n<=maxcol;n++){
//							if(col_number.contains(n))
//								sql.append(i);
//							else
//								sql.append("0");
//							ColumnInfo colInfo = list.get(n-1);
//							if(colInfo.getType().equals("CHAR")){
//								sql.append("'");
//							}
//							sql.append(InsertDataMain.valGen(colInfo.getType(), colInfo.getLenth(), i));
//							if(colInfo.getType().equals("CHAR")){
//								sql.append("'");
//							}
							sql.append("?");
							
							if(n<maxcol)
								sql.append(",");
						}
						
						sql.append(");");
			
						System.out.println(sql.toString());
						ps = conn.prepareStatement(sql.toString());
					}
					
					ArrayList<ColumnInfo> list = TableParser.parseTable(table);

					sql = new StringBuffer();
					
					StringBuffer val = new StringBuffer();
					
					val.append("INSERT INTO " + table);
					val.append(" VALUES (");
					
					for(int m=1;m<=maxcol;m++){ 
						String strval = null;
						int intval = -1;
						ColumnInfo colInfo = list.get(m-1);
						if(colInfo.getType().equals("CHAR")) {
							strval = InsertDataMain.valGen(colInfo.getType(), colInfo.len, i);
							val.append("'");
							val.append(strval);
							val.append("'");
							ps.setString(m, strval);
						} else{
							intval = Integer.parseInt(InsertDataMain.valGen(colInfo.getType(), colInfo.len, i));
							val.append(intval);
							ps.setInt(m, intval);
						}
						if(m<maxcol)
							val.append(",");
					}
					
					val.append(");");
					System.out.println(val.toString());
					ps.executeUpdate();
				}
				
			}
			
//			conn.commit();
		} catch (SQLException e) {
//			try {
//				conn.rollback();
//			} catch (SQLException e1) {
//				e1.printStackTrace();
//			}
			e.printStackTrace();
		} catch (Exception e1) {
			e1.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	public static String valGen(String type, int len, int seed){	
		int max =  (int) (Math.pow(10,len) - 1);
		int val = seed%max;
		return String.valueOf(val);
	}

}
