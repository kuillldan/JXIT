// @ @ @ START COPYRIGHT @ @ @
//
// Copyright 2004
// Hewlett-Packard Development Company, L.P.
// Protected as an unpublished work.
// All rights reserved.
//
// The computer program listings, specifications and
// documentation herein are the property of Compaq Computer
// Corporation and successor entities such as Hewlett-Packard
// Development Company, L.P., or a third party supplier and
// shall not be reproduced, copied, disclosed, or used in whole
// or in part for any reason without the prior express written
// permission of Hewlett-Packard Development Company, L.P.
//
// @ @ @ END COPYRIGHT @ @ @

//
// You are granted a limited copyright to modify and use this sample
// code for your internal purposes only. THIS SOFTWARE IS PROVIDED "AS-
// IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
// NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
// PARTICULAR PURPOSE OR NONINFRINGEMENT. IN NO EVENT SHALL THE
// HEWLETT-PACKARD COMPANY OR ITS SUBSIDIARIES BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT
// OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
// SOFTWARE INCURRED BY YOU OR ANY THIRD PARTY IN CONNECTION WITH THE
// USE OF THIS SOFTWARE.
//


package regbeans;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import java.sql.*;
import javax.sql.*;
import java.rmi.*;
import java.util.logging.*;


public class LoginServlet extends HttpServlet {
  private static final String CONTENT_TYPE = "text/html";
  private Connection pointBaseConn=null;
  private PreparedStatement selPB1=null;
  private DataSource pointBaseDS=null;


  //Initialize global variables
  public void init() throws ServletException {
    //Get the intial context to look up the DataSource
    Context ctx = null;
    Hashtable env = new Hashtable();
    env.put(Context.INITIAL_CONTEXT_FACTORY, "weblogic.jndi.WLInitialContextFactory");

    try {
      //Get the 2 DataSources for NonStop SQL/MX and PointBase - can throw NamingException
      ctx = new InitialContext(env);
      pointBaseDS = (javax.sql.DataSource)ctx.lookup("TwoPhaseDS-PointBase");
      pointBaseConn = pointBaseDS.getConnection();
      selPB1 = pointBaseConn.prepareStatement("select password from twophase.logon where email=?");
    }
    catch (NamingException ne) {
      StringWriter sw = new StringWriter();
      sw.write("Naming Exception. Failed to look up DataSource...\n");
      sw.write(ne.toString());
      PrintWriter out = new PrintWriter(sw);
      ne.printStackTrace(out);
      out.flush();
      FileLogger.writeToLog(Level.SEVERE, sw.toString());
      throw new ServletException(sw.toString());
    }
    catch (SQLException sqle) {
      StringWriter sw = new StringWriter();
      sw.write("SQL Exception. Failed to connect to Database...\n");
      sw.write(sqle.toString());
      PrintWriter out = new PrintWriter(sw);
      sqle.printStackTrace(out);
      out.flush();
      FileLogger.writeToLog(Level.SEVERE, sw.toString());
      throw new ServletException(sw.toString());
    }
  }


  //Process the HTTP Get request
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();
    out.println("<html>");
    out.println("<head><title>Servlet2</title></head>");
    out.println("<body bgcolor=\"#ffffff\">");
    out.println("<p>The servlet has received a GET. This is the reply.</p>");
    out.println("</body></html>");
  }

  //Process the HTTP Post request
  public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    LoginBean loginBean = (LoginBean)request.getAttribute ("loginHandler");
    String userPwd = loginBean.getPwd();
    String userId = loginBean.getUserID();

    try {
      selPB1.setString(1, userId);
      ResultSet rs = selPB1.executeQuery();
      if (rs.next()) {
         //User exists in the database
         String dbPswd = rs.getString(1);
         userPwd = userPwd.trim();
         dbPswd = dbPswd.trim();
         if (userPwd.equals(dbPswd)) {
           request.setAttribute("UserName", userId);
           getServletConfig().getServletContext().getRequestDispatcher("/BookCatalog.jsp").forward(request, response);
         }
         else {
           loginBean.setErrors("servletError","Password is incorrect. Please try again");
           getServletConfig().getServletContext().getRequestDispatcher("/Login.jsp").forward(request, response);
         }
      }
      else {
         //User does not exist in the database
         loginBean.setErrors("servletError","User does not exist in the database. Please try again");
         getServletConfig().getServletContext().getRequestDispatcher("/Login.jsp").forward(request, response);
      }
    }
    catch (SQLException sqle) {
      StringWriter sw = new StringWriter();
      sw.write("SQL Exception. Error accessing the database...\n");
      PrintWriter out = new PrintWriter(sw);
      sqle.printStackTrace(out);
      out.flush();
      FileLogger.writeToLog(Level.SEVERE, sw.toString());
      loginBean.setErrors("servletError","Database access error");
      getServletConfig().getServletContext().getRequestDispatcher("/Login.jsp").forward(request, response);
    }
  }


  //Clean up resources
  public void destroy() {
    try {
      pointBaseConn.close();
    }
    catch(SQLException sqle) {
      //No-op since the servlet is being destroyed anyway
    }
  }
}