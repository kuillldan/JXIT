// @ @ @ START COPYRIGHT @ @ @
//
// Copyright 2004
// Hewlett-Packard Development Company, L.P.
// Protected as an unpublished work.
// All rights reserved.
//
// The computer program listings, specifications and
// documentation herein are the property of Compaq Computer
// Corporation and successor entities such as Hewlett-Packard
// Development Company, L.P., or a third party supplier and
// shall not be reproduced, copied, disclosed, or used in whole
// or in part for any reason without the prior express written
// permission of Hewlett-Packard Development Company, L.P.
//
// @ @ @ END COPYRIGHT @ @ @

//
// You are granted a limited copyright to modify and use this sample
// code for your internal purposes only. THIS SOFTWARE IS PROVIDED "AS-
// IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
// NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
// PARTICULAR PURPOSE OR NONINFRINGEMENT. IN NO EVENT SHALL THE
// HEWLETT-PACKARD COMPANY OR ITS SUBSIDIARIES BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT
// OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
// SOFTWARE INCURRED BY YOU OR ANY THIRD PARTY IN CONNECTION WITH THE
// USE OF THIS SOFTWARE.
//


package regbeans;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import java.sql.*;
import javax.sql.*;
import java.rmi.*;
import java.util.logging.*;
import javax.transaction.UserTransaction;
import javax.transaction.SystemException;
import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.NotSupportedException;
import javax.transaction.RollbackException;



public class DbsCreateServlet extends HttpServlet {
  private static final String CONTENT_TYPE = "text/html";
  private Connection pointBaseConn=null, mxConn=null;
  private PreparedStatement selPB1=null;
  private DataSource pointBaseDS=null, mxDS=null;
  boolean pbDb=false, mxDb=false, pbTest=false, mxTest=false;
  StringBuffer errorMsg = new StringBuffer();
  UserTransaction txn;

  //Initialize global variables
  public void init() throws ServletException {
    //Get the intial context to look up the DataSource
    Context ctx = null;
    Hashtable env = new Hashtable();
    env.put(Context.INITIAL_CONTEXT_FACTORY, "weblogic.jndi.WLInitialContextFactory");

    try {
      //Get the 2 DataSources for NonStop SQL/MX and PointBase - can throw NamingException
      ctx = new InitialContext(env);
      pointBaseDS = (javax.sql.DataSource)ctx.lookup("TwoPhaseDS-PointBase");
      FileLogger.writeToLog(Level.INFO, "Looked up TwoPhaseDS-PointBase");
      mxDS = (javax.sql.DataSource)ctx.lookup("TwoPhaseDS-SqlMx");
      FileLogger.writeToLog(Level.INFO, "Looked up TwoPhaseDS-SqlMx");

      //Get the UserTransaction Object
      txn = (UserTransaction) ctx.lookup("javax.transaction.UserTransaction");
      FileLogger.writeToLog(Level.INFO, "Looked up UserTransaction");
    }
    catch (NamingException ne) {
      StringWriter sw = new StringWriter();
      sw.write("Naming Exception. Failed to look up DataSource...\n");
      PrintWriter out = new PrintWriter(sw);
      ne.printStackTrace(out);
      out.flush();
      FileLogger.writeToLog(Level.SEVERE, sw.toString());
      throw new ServletException(sw.toString());
    }
  }


  //Process the HTTP Get request
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();
    out.println("<html>");
    out.println("<head><title>Servlet2</title></head>");
    out.println("<body bgcolor=\"#ffffff\">");
    out.println("<p>The servlet has received a GET. This is the reply.</p>");
    out.println("</body></html>");
  }


  //Process the HTTP Post request
  public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    Statement pbStmt, mxStmt;
    String url, uid, pswd, nskVolName;
    DbsCreateBean dbsCreateHandler = (DbsCreateBean)request.getAttribute("dbsCreateHandler");

    try {
       errorMsg.setLength(0);  //set the stringbuffer to empty string before starting POST processing
       txn.begin();
       pbDb = createPbDb();

       if (pbDb) {
         FileLogger.writeToLog(Level.INFO, "Created PointBase database successfully");
         mxDb = createMxDb(request);
         if (mxDb) {
           FileLogger.writeToLog(Level.INFO, "Created NonStop SQL/MX database successfully");
           txn.commit();
           txn.begin();  //for testing connections
           if (testDbConnections()) {
             FileLogger.writeToLog(Level.INFO, "Tested database connections successfully");
             txn.commit();
           }
           else {
             FileLogger.writeToLog(Level.INFO, "Error testing database connections");
             txn.rollback();
             dbsCreateHandler.setErrors("servletError", errorMsg.toString());
             getServletConfig().getServletContext().getRequestDispatcher("/DbsCreateResponse.jsp").forward(request, response);
           }
         }
         else {
           FileLogger.writeToLog(Level.INFO, "Error creating NonStop SQL/MX database");
           txn.rollback();
           dbsCreateHandler.setErrors("servletError", errorMsg.toString());
           getServletConfig().getServletContext().getRequestDispatcher("/DbsCreateResponse.jsp").forward(request, response);
         }
       }
       else {
         FileLogger.writeToLog(Level.INFO, "Error creating PointBase database");
         txn.rollback();
         dbsCreateHandler.setErrors("servletError", errorMsg.toString());
         getServletConfig().getServletContext().getRequestDispatcher("/DbsCreateResponse.jsp").forward(request, response);
       }

    }
    catch (NotSupportedException nse) {
      StringWriter sw = new StringWriter();
      sw.write("Transaction manager cannot start transaction \n");
      sw.write(nse.toString());
      PrintWriter out = new PrintWriter(sw);
      nse.printStackTrace(out);
      out.flush();
      FileLogger.writeToLog(Level.SEVERE, sw.toString());
      dbsCreateHandler.setErrors("servletError","Transaction begin error. See log file for details");
      getServletConfig().getServletContext().getRequestDispatcher("/DbsCreateResponse.jsp").forward(request, response);
   }
   catch (SystemException se) {
      StringWriter sw = new StringWriter();
      sw.write("Transaction manager encountered an unexpected error condition \n");
      sw.write(se.toString());
      PrintWriter out = new PrintWriter(sw);
      se.printStackTrace(out);
      out.flush();
      FileLogger.writeToLog(Level.SEVERE, sw.toString());
      dbsCreateHandler.setErrors("servletError","Transaction error. See log file for details");
      getServletConfig().getServletContext().getRequestDispatcher("/DbsCreateResponse.jsp").forward(request, response);
   }
   catch (RollbackException rbe) {
      StringWriter sw = new StringWriter();
      sw.write("Error Committing the transaction. Transaction rolled back\n");
      sw.write(rbe.toString());
      PrintWriter out = new PrintWriter(sw);
      rbe.printStackTrace(out);
      out.flush();
      FileLogger.writeToLog(Level.SEVERE, sw.toString());
      dbsCreateHandler.setErrors("servletError","Transaction error. See log file for details");
      getServletConfig().getServletContext().getRequestDispatcher("/DbsCreateResponse.jsp").forward(request, response);
    }
    catch ( HeuristicMixedException hmse) {
      StringWriter sw = new StringWriter();
      sw.write("Heuristic error. \n");
      sw.write(hmse.toString());
      PrintWriter out = new PrintWriter(sw);
      hmse.printStackTrace(out);
      out.flush();
      FileLogger.writeToLog(Level.SEVERE, sw.toString());
      dbsCreateHandler.setErrors("servletError","Transaction error. See log file for details");
      getServletConfig().getServletContext().getRequestDispatcher("/DbsCreateResponse.jsp").forward(request, response);
    }
    catch ( HeuristicRollbackException hrbe) {
      StringWriter sw = new StringWriter();
      sw.write("Heuristic Rollback. \n");
      sw.write(hrbe.toString());
      PrintWriter out = new PrintWriter(sw);
      hrbe.printStackTrace(out);
      out.flush();
      FileLogger.writeToLog(Level.SEVERE, sw.toString());
      dbsCreateHandler.setErrors("servletError","Transaction error. See log file for details");
      getServletConfig().getServletContext().getRequestDispatcher("/DbsCreateResponse.jsp").forward(request, response);
    }

    //Send the msg back to the JSP
    dbsCreateHandler.setErrors("servletError", errorMsg.toString());
    getServletConfig().getServletContext().getRequestDispatcher("/DbsCreateResponse.jsp").forward(request, response);
  }

  //Clean up resources
  public void destroy() {
  }

  private boolean createPbDb() {
    Statement pbStmt;
    boolean result = false;

    try {
      pointBaseConn = pointBaseDS.getConnection();

      //Create the Pointbase database first
      pbStmt = pointBaseConn.createStatement();
      pbStmt.executeUpdate("create schema TwoPhase");
      pbStmt.executeUpdate("CREATE TABLE TWOPHASE.LOGON " +
                          "(email CHARACTER ( 50)  NOT NULL " +
                          ", password CHARACTER ( 50)  NOT NULL " +
                          ", custid INTEGER IDENTITY  NOT NULL " +
                          ",CONSTRAINT PKey PRIMARY KEY ( email))");
      errorMsg.append("PointBase database created successfully \n");
      pbDb = true;
      result = true;
      pbStmt.close();
      pointBaseConn.close();
    }
    catch (SQLException sqle) {
      StringBuffer sb = new StringBuffer();
      SQLException nextException;
      nextException = sqle;
      do {
        sb.append(nextException.getMessage());
        sb.append("SQLState   " + nextException.getSQLState());
        sb.append("Error Code " + nextException.getErrorCode());
      } while ((nextException = nextException.getNextException()) != null);
      FileLogger.writeToLog(Level.SEVERE, sb.toString());
      errorMsg.append("Error creating Pointbase database. See log file for details");
    }
    return result;
  }

  private boolean createMxDb(HttpServletRequest request) {
    Statement mxStmt;
    boolean result = false;
    String url, uid, pswd, nskVolName;
    DbsCreateBean dbsCreateHandler = (DbsCreateBean)request.getAttribute("dbsCreateHandler");

    try {
       //Now create the NonStop SQL/MX database. Don't use the NonStop SQL/MX DataSource
       //since its configured with a catalog and schema that have not been created
       nskVolName = dbsCreateHandler.getNskVol();
       mxConn = mxDS.getConnection();
       mxStmt = mxConn.createStatement();

       //Create the catalog and schema
       if (nskVolName.length() <= 0) {
         mxStmt.executeUpdate("create catalog wls_twophase");
       }
       else {
         mxStmt.executeUpdate("create catalog wls_twophase location " + nskVolName);
       }
       mxStmt.executeUpdate("create schema wls_twophase.twophase");

       //Create the TwoPhase tables
       mxStmt.executeUpdate("CREATE TABLE wls_twophase.twophase.newuser  ( " +
                            "id        NUMERIC (9) UNSIGNED NO DEFAULT NOT NULL NOT DROPPABLE" +
                            ",fname    VARCHAR (60) NOT NULL NOT DROPPABLE" +
                            ",lname    VARCHAR(60) NOT NULL NOT DROPPABLE" +
                            ",phone    VARCHAR(12) NOT NULL NOT DROPPABLE" +
                            ",license  VARCHAR(10) NOT NULL NOT DROPPABLE" +
                            ",zip      VARCHAR(10) NOT NULL NOT DROPPABLE" +
                            ",city     VARCHAR(60) NOT NULL NOT DROPPABLE" +
                            ",address1 VARCHAR(100) NOT NULL NOT DROPPABLE" +
                            ",address2 VARCHAR(100) DEFAULT NULL " +
                            ",PRIMARY KEY  (id) NOT DROPPABLE)");

       mxStmt.executeUpdate("CREATE TABLE wls_twophase.twophase.books  ( " +
                            "author    VARCHAR (60) NOT NULL NOT DROPPABLE" +
                            ",title    VARCHAR(200) NOT NULL NOT DROPPABLE" +
                            ",subject  VARCHAR(60) NOT NULL NOT DROPPABLE)");

       errorMsg.append("NonStop SQL/MX database created successfully\n");

       //Inserting data into the books table
       mxStmt.executeUpdate("insert into wls_twophase.twophase.books values ('Frances Mayes', 'In Tuscany', 'Travel')");
       mxStmt.executeUpdate("insert into wls_twophase.twophase.books values ('Jimmy Cornell', 'World Cruising Routes', 'Travel')");
       mxStmt.executeUpdate("insert into wls_twophase.twophase.books values ('Peter Greenberg', 'Hotel Secrets from the Travel Detective', 'Travel')");
       mxStmt.executeUpdate("insert into wls_twophase.twophase.books values ('Jon Krakauer', 'Into Thin Air', 'Travel')");
       mxStmt.executeUpdate("insert into wls_twophase.twophase.books values ('Jon Krakauer', 'In the Wild', 'Travel')");

       mxStmt.executeUpdate("insert into wls_twophase.twophase.books values ('Charles.M.Schulz', 'The Complete Peanuts', 'Comics')");
       mxStmt.executeUpdate("insert into wls_twophase.twophase.books values ('Michael Farr', 'Tintin: The Complete Companion', 'Comics')");
       mxStmt.executeUpdate("insert into wls_twophase.twophase.books values ('Bill Watterson', 'The Essential Calvin and Hobbes', 'Comics')");
       mxStmt.executeUpdate("insert into wls_twophase.twophase.books values ('Rene Goscinny', 'Asterix and the Actress', 'Comics')");
       mxStmt.executeUpdate("insert into wls_twophase.twophase.books values ('Rene Goscinny', 'Asterix the Gaul', 'Comics')");

       mxStmt.executeUpdate("insert into wls_twophase.twophase.books values ('Sarah Susanka', 'Not So Big Solutions for Your Home', 'Home & Garden')");
       mxStmt.executeUpdate("insert into wls_twophase.twophase.books values ('Kate Spade', 'Occasions', 'Home & Garden')");
       mxStmt.executeUpdate("insert into wls_twophase.twophase.books values ('Cheryl Mendelson', 'Home Comforts: The Art and Science of Keeping House', 'Home & Garden')");
       mxStmt.executeUpdate("insert into wls_twophase.twophase.books values ('Mel Bartholomew', 'Square Foot Gardening', 'Home & Garden')");
       mxStmt.executeUpdate("insert into wls_twophase.twophase.books values ('Brian Santos', 'Painting Secrets', 'Home & Garden')");

       mxStmt.executeUpdate("insert into wls_twophase.twophase.books values ('Charles Dickens', 'A Tale of Two Cities', 'Literature')");
       mxStmt.executeUpdate("insert into wls_twophase.twophase.books values ('William Shakespeare', 'Hamlet', 'Literature')");
       mxStmt.executeUpdate("insert into wls_twophase.twophase.books values ('Emily Bronte', 'Wuthering Heights', 'Literature')");
       mxStmt.executeUpdate("insert into wls_twophase.twophase.books values ('Kahlil Gibran', 'The Prophet', 'Literature')");
       mxStmt.executeUpdate("insert into wls_twophase.twophase.books values ('Oscar Wilde', 'The Importance of Being Earnest', 'Literature')");

       mxStmt.executeUpdate("insert into wls_twophase.twophase.books values ('David Allen Sibly', 'The Sibley Guide to Birds', 'Outdoors & Nature')");
       mxStmt.executeUpdate("insert into wls_twophase.twophase.books values ('Rachel Carson', 'Silent Spring', 'Outdoors & Nature')");
       mxStmt.executeUpdate("insert into wls_twophase.twophase.books values ('Robert Post', 'Reading the Water', 'Outdoors & Nature')");
       mxStmt.executeUpdate("insert into wls_twophase.twophase.books values ('Rene Harrop', 'Trout Hunter', 'Outdoors & Nature')");
       mxStmt.executeUpdate("insert into wls_twophase.twophase.books values ('James Herriot', 'All Creatures Great and Small', 'Outdoors & Nature')");

       errorMsg.append("Inserted data into SQL/MX books table successfully\n");
       result = true;
       mxStmt.close();
       mxConn.close();
    }
    catch (SQLException sqle) {
      StringBuffer sb = new StringBuffer();
      SQLException nextException;
      nextException = sqle;
      do {
        sb.append(nextException.getMessage());
        sb.append("SQLState   " + nextException.getSQLState());
        sb.append("Error Code " + nextException.getErrorCode());
      } while ((nextException = nextException.getNextException()) != null);
      FileLogger.writeToLog(Level.SEVERE, sb.toString());
      errorMsg.append("Error creating NonStop SQL/MX database database. See log file for details");
    }
    return result;
  }

  private boolean testDbConnections() {
    //Test the connections from the database after creating the databases
    Connection pbConn1=null, mxConn1 = null;
    Statement testStmt1, testStmt2;
    boolean result = false, pbTest = false, mxTest=false;

    try {
      pbConn1 = pointBaseDS.getConnection();
      testStmt1 = pbConn1.createStatement();
      testStmt1.execute("select * from twophase.logon");
      pbTest = true;
      errorMsg.append("Tested connection to the PointBase Connection Pool successfully\n");
      FileLogger.writeToLog(Level.INFO, "Tested connection to the PointBase Connection Pool successfully\n");

      mxConn1 = mxDS.getConnection();
      testStmt2 = mxConn1.createStatement();
      testStmt2.execute("select * from wls_twophase.twophase.newuser");
      mxTest = true;
      errorMsg.append("Tested connection to the NonStop SQL/MX Connection Pool successfully\n");
      FileLogger.writeToLog(Level.INFO,"Tested connection to the NonStop SQL/MX Connection Pool successfully\n");
      result = true;
      testStmt1.close();
      testStmt2.close();
      pbConn1.close();
      mxConn1.close();
    }
    catch (SQLException sqle) {
      StringBuffer sb = new StringBuffer();
      SQLException nextException;
      nextException = sqle;
      do {
        sb.append(nextException.getMessage());
        sb.append("SQLState   " + nextException.getSQLState());
        sb.append("Error Code " + nextException.getErrorCode());
      } while ((nextException = nextException.getNextException()) != null);
      FileLogger.writeToLog(Level.SEVERE, sb.toString());
      if (!pbTest) {
         errorMsg.append("Connection test to Pointbase database failed. See log file for details");
      }
      else if (!mxTest) {
         errorMsg.append("Connection test to NonStop SQL/MX database failed. See log file for details");
      }
    }
    return result;
   }

}
