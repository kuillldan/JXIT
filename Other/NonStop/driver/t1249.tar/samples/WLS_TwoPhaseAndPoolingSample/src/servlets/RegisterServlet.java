// @ @ @ START COPYRIGHT @ @ @
//
// Copyright 2004
// Hewlett-Packard Development Company, L.P.
// Protected as an unpublished work.
// All rights reserved.
//
// The computer program listings, specifications and
// documentation herein are the property of Compaq Computer
// Corporation and successor entities such as Hewlett-Packard
// Development Company, L.P., or a third party supplier and
// shall not be reproduced, copied, disclosed, or used in whole
// or in part for any reason without the prior express written
// permission of Hewlett-Packard Development Company, L.P.
//
// @ @ @ END COPYRIGHT @ @ @

//
// You are granted a limited copyright to modify and use this sample
// code for your internal purposes only. THIS SOFTWARE IS PROVIDED "AS-
// IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
// NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
// PARTICULAR PURPOSE OR NONINFRINGEMENT. IN NO EVENT SHALL THE
// HEWLETT-PACKARD COMPANY OR ITS SUBSIDIARIES BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT
// OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
// SOFTWARE INCURRED BY YOU OR ANY THIRD PARTY IN CONNECTION WITH THE
// USE OF THIS SOFTWARE.
//


package regbeans;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import java.sql.*;
import javax.sql.*;
import java.rmi.*;
import java.util.logging.*;
import javax.transaction.UserTransaction;
import javax.transaction.SystemException;
import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.NotSupportedException;
import javax.transaction.RollbackException;
//import javax.transaction.IllegalStateException;
//import javax.transaction.SecurityException;


/**
 * <p>Title: RegisterServlet.java </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class RegisterServlet extends HttpServlet implements SingleThreadModel {
  private static final String CONTENT_TYPE = "text/html";
  private Connection sqlMxConn=null, pointBaseConn=null;
  private PreparedStatement insPB1=null, selPB1=null, insMX1=null;
  private DataSource sqlMxDS=null, pointBaseDS=null;
  private UserTransaction tx=null;

  //Initialize global variables
  public void init() throws ServletException {
    //Get the intial context to look up the DataSource
    Context ctx = null;
    Hashtable env = new Hashtable();
    env.put(Context.INITIAL_CONTEXT_FACTORY, "weblogic.jndi.WLInitialContextFactory");

    try {
      //Get the 2 DataSources for NonStop SQL/MX and PointBase - can throw NamingException
      ctx = new InitialContext(env);
      sqlMxDS = (javax.sql.DataSource)ctx.lookup("TwoPhaseDS-SqlMx");
      pointBaseDS = (javax.sql.DataSource)ctx.lookup("TwoPhaseDS-PointBase");

      //Get the UserTransaction Object
      tx = (UserTransaction) ctx.lookup("javax.transaction.UserTransaction");
    }
    catch (NamingException ne) {
      StringWriter sw = new StringWriter();
      sw.write("Naming Exception. Failed to look up DataSource...\n");
      sw.write(ne.toString());
      PrintWriter out = new PrintWriter(sw);
      ne.printStackTrace(out);
      out.flush();
      FileLogger.writeToLog(Level.SEVERE, sw.toString());
      throw new ServletException(sw.toString());
    }
  }


  //Process the HTTP Get request
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

  }


  //Process the HTTP Post request
  public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    RegisterBean registerBean = (RegisterBean)request.getAttribute ("registerHandler");

    //Begin the transaction
   try {
     tx.begin();

     //Get the form values and insert them into the database
     //A 2 phase commit is done - the email and password form values are inserted into the
     //Logon table in PointBase (TwoPhase schema). The Logon table has an autoincrement userId column.
     //The User table in NonStop SQL/MX is updated with all the other form values and the max(custId)
     //of the PointBase Logon table
     //int maxCustId = getMaxCustIdFromLogon();
     //System.out.println("The maxCustId is: " + maxCustId);

     boolean insertDone = doTwoPhaseCommit( registerBean, request);
     sqlMxConn.close();
     pointBaseConn.close();

     if (insertDone) {
     tx.commit();
       getServletConfig().getServletContext().getRequestDispatcher("/RegisterDone.jsp").forward(request, response);
     }
     else {
       tx.rollback();
       registerBean.setErrors("servletError","Database access error");
       getServletConfig().getServletContext().getRequestDispatcher("/RetryRegister.jsp").forward(request, response);
     }
   }
   catch (SQLException sqle) {
      StringWriter sw = new StringWriter();
      sw.write("Transaction manager cannot start transaction \n");
      sw.write(sqle.toString());
      PrintWriter out = new PrintWriter(sw);
      sqle.printStackTrace(out);
      out.flush();
      FileLogger.writeToLog(Level.SEVERE, sw.toString());
      registerBean.setErrors("servletError","Transaction error. See log file for details");
      getServletConfig().getServletContext().getRequestDispatcher("/RetryRegister.jsp").forward(request, response);
   }
   catch (NotSupportedException nse) {
      StringWriter sw = new StringWriter();
      sw.write("Transaction manager cannot start transaction \n");
      sw.write(nse.toString());
      PrintWriter out = new PrintWriter(sw);
      nse.printStackTrace(out);
      out.flush();
      FileLogger.writeToLog(Level.SEVERE, sw.toString());
      registerBean.setErrors("servletError","Transaction error. See log file for details");
      getServletConfig().getServletContext().getRequestDispatcher("/RetryRegister.jsp").forward(request, response);
    }
    catch (SystemException se) {
      StringWriter sw = new StringWriter();
      sw.write("Transaction manager encountered an unexpected error condition \n");
      sw.write(se.toString());
      PrintWriter out = new PrintWriter(sw);
      se.printStackTrace(out);
      out.flush();
      FileLogger.writeToLog(Level.SEVERE, sw.toString());
      registerBean.setErrors("servletError","Transaction error. See log file for details");
      getServletConfig().getServletContext().getRequestDispatcher("/RetryRegister.jsp").forward(request, response);
    }
    catch (RollbackException rbe) {
      StringWriter sw = new StringWriter();
      sw.write("Error Committing the transaction. Transaction rolled back\n");
      sw.write(rbe.toString());
      PrintWriter out = new PrintWriter(sw);
      rbe.printStackTrace(out);
      out.flush();
      FileLogger.writeToLog(Level.SEVERE, sw.toString());
      registerBean.setErrors("servletError","Transaction error. See log file for details");
      getServletConfig().getServletContext().getRequestDispatcher("/RetryRegister.jsp").forward(request, response);
    }
    catch ( HeuristicMixedException hmse) {
      StringWriter sw = new StringWriter();
      sw.write("Heuristic error \n");
      sw.write(hmse.toString());
      PrintWriter out = new PrintWriter(sw);
      hmse.printStackTrace(out);
      out.flush();
      FileLogger.writeToLog(Level.SEVERE, sw.toString());
      registerBean.setErrors("servletError","Transaction error. See log file for details");
      getServletConfig().getServletContext().getRequestDispatcher("/RetryRegister.jsp").forward(request, response);
    }
    catch ( HeuristicRollbackException hrbe) {
      StringWriter sw = new StringWriter();
      sw.write("Heuristic rollback \n");
      sw.write(hrbe.toString());
      PrintWriter out = new PrintWriter(sw);
      hrbe.printStackTrace(out);
      out.flush();
      FileLogger.writeToLog(Level.SEVERE, sw.toString());
      registerBean.setErrors("servletError","Transaction error. See log file for details");
      getServletConfig().getServletContext().getRequestDispatcher("/RetryRegister.jsp").forward(request, response);
    }
 }


  //Clean up resources
  public void destroy() {

  }

  // private boolean doTwoPhaseCommit(int maxCustId, RegisterBean registerBean) {
  private boolean doTwoPhaseCommit( RegisterBean registerBean, HttpServletRequest request) {
    boolean success=false;
    int maxId=0;

    try {
      //Get the PointBase DB connection after txn begin since its a XA txn
      pointBaseConn = pointBaseDS.getConnection();
      StringBuffer sqlStr = new StringBuffer("insert into twophase.logon values(\'");
      sqlStr.append(registerBean.getEmail());
      sqlStr.append("\', \'");
      sqlStr.append(registerBean.getPassword());
      sqlStr.append("\')");
      Statement s1 = pointBaseConn.createStatement();
      s1.execute(sqlStr.toString(), Statement.RETURN_GENERATED_KEYS );
      ResultSet rs = s1.getGeneratedKeys();
      if (rs.next()) {
        maxId = rs.getInt(1);
        rs.close();
      }
      else {
        FileLogger.writeToLog(Level.SEVERE, "Error getting Max CustId from PointBase");
        return success;
      }

      //Open the connection to NonStop SQL/MX after the transaction has started since its XA
      //Insert the corresponding record in the NonStop SQL/MX database
      sqlMxConn = sqlMxDS.getConnection();
      insMX1 = sqlMxConn.prepareStatement("insert into newuser values(?, ?, ?, ?, ?, ?, ?, ?, ?)");
      insMX1.setInt(1, maxId);
      //insMX1.setString(2, registerBean.getFirstName());
      //insMX1.setString(3, registerBean.getLastName());
      insMX1.setString(2, request.getParameter("firstName"));
      insMX1.setString(3, request.getParameter("lastName"));
      insMX1.setString(4, registerBean.getPhone());
      //insMX1.setString(5, registerBean.getLicense());
      insMX1.setString(5, request.getParameter("license"));
      insMX1.setString(6, registerBean.getZip());
      insMX1.setString(7, registerBean.getCity());
      insMX1.setString(8, registerBean.getAddress1());
      insMX1.setString(9, registerBean.getAddress2());
      insMX1.executeUpdate();
    }
    catch (SQLException sqle) {
      StringWriter sw = new StringWriter();
      maxId = 0;
      sw.write(sqle.getMessage());
      PrintWriter out = new PrintWriter(sw);
      sqle.printStackTrace(out);
      out.flush();
      FileLogger.writeToLog(Level.SEVERE, sw.toString());
      return success;
    }

    success=true;
    return success;
  } // end of private method doTwoPhaseCommit

  //Private method to get the max CustId from the Logon table in the PointBase database
  //This method is not called any more
  private int getMaxCustIdFromLogon() {
    int maxId=0;

    try {
      //Open connections to PointBase - can throw SQLException
      pointBaseConn = pointBaseDS.getConnection();
      System.out.println("Got POintBase database connection");

      selPB1 = pointBaseConn.prepareStatement("select max(custId) from twophase.logon");
      System.out.println("Prepared statements");
      ResultSet rs = selPB1.executeQuery();
      rs.next();
      maxId = rs.getInt(1);
      if (rs.wasNull()) {
        maxId=1;
      }
    }
    catch (SQLException sqle) {
      //TO DO: log SQL exception stack trace to log file
      //just set maxId to 0
      System.out.println(sqle.getMessage());
      System.out.println(sqle.getStackTrace());
      maxId=0;
    }
    return maxId;
  } // end of private getMaxCustIdFromLogon
}


