// @ @ @ START COPYRIGHT @ @ @
//
// Copyright 2004
// Hewlett-Packard Development Company, L.P.
// Protected as an unpublished work.
// All rights reserved.
//
// The computer program listings, specifications and
// documentation herein are the property of Compaq Computer
// Corporation and successor entities such as Hewlett-Packard
// Development Company, L.P., or a third party supplier and
// shall not be reproduced, copied, disclosed, or used in whole
// or in part for any reason without the prior express written
// permission of Hewlett-Packard Development Company, L.P.
//
// @ @ @ END COPYRIGHT @ @ @

//
// You are granted a limited copyright to modify and use this sample
// code for your internal purposes only. THIS SOFTWARE IS PROVIDED "AS-
// IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
// NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
// PARTICULAR PURPOSE OR NONINFRINGEMENT. IN NO EVENT SHALL THE
// HEWLETT-PACKARD COMPANY OR ITS SUBSIDIARIES BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT
// OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
// SOFTWARE INCURRED BY YOU OR ANY THIRD PARTY IN CONNECTION WITH THE
// USE OF THIS SOFTWARE.
//


package regbeans;

import java.util.logging.*;
import java.io.IOException;

 public class FileLogger   {
   private static Logger logger = null;
   private static FileHandler logFile = null;

   static {
     try {
       logger = Logger.getLogger("regbeans.FileLogger");
       logger.setUseParentHandlers(false);
       FileHandler logFile = new FileHandler("TwoPhaseSampleLog.txt");
       SimpleFormatter smpl = new SimpleFormatter();
       logFile.setFormatter(smpl);
       logger.setLevel(Level.INFO);
       logger.addHandler(logFile);
     }
     catch(IOException ioe) {
       System.out.println("TwoPhaseSample: Error creating log file");
       ioe.getMessage();
       ioe.getStackTrace();
       ioe.getCause();
     }
   }


   public FileLogger(){
   }

   public static void writeToLog(Level logLevel, String msgToLog) {
      if (logLevel == Level.INFO) {
        logger.info(msgToLog);
      }
      else if (logLevel == Level.SEVERE) {
        logger.severe(msgToLog);
      }
   }

   public static FileHandler getFileHandler() {
      return logFile;
   }

 }
