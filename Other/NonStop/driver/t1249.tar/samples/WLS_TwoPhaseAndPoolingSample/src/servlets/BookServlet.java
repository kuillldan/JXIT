// @ @ @ START COPYRIGHT @ @ @
//
// Copyright 2004
// Hewlett-Packard Development Company, L.P.
// Protected as an unpublished work.
// All rights reserved.
//
// The computer program listings, specifications and
// documentation herein are the property of Compaq Computer
// Corporation and successor entities such as Hewlett-Packard
// Development Company, L.P., or a third party supplier and
// shall not be reproduced, copied, disclosed, or used in whole
// or in part for any reason without the prior express written
// permission of Hewlett-Packard Development Company, L.P.
//
// @ @ @ END COPYRIGHT @ @ @

//
// You are granted a limited copyright to modify and use this sample
// code for your internal purposes only. THIS SOFTWARE IS PROVIDED "AS-
// IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
// NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
// PARTICULAR PURPOSE OR NONINFRINGEMENT. IN NO EVENT SHALL THE
// HEWLETT-PACKARD COMPANY OR ITS SUBSIDIARIES BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT
// OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
// SOFTWARE INCURRED BY YOU OR ANY THIRD PARTY IN CONNECTION WITH THE
// USE OF THIS SOFTWARE.
//


package regbeans;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import java.sql.*;
import javax.sql.*;
import java.rmi.*;
import java.util.logging.*;
import com.tandem.t4jdbc.*;
import weblogic.jdbc.extensions.*;



public class BookServlet extends HttpServlet {
  private static final String CONTENT_TYPE = "text/html";
  private Connection mxConn=null;
  private PreparedStatement selMx=null;
  private DataSource mxDS=null;
  private final String[] authors = {"Author1", "Author2", "Author3", "Author4", "Author5"};
  private final String[] titles = {"Title1", "Title2", "Title3", "Title4", "Title5"};

  //Initialize global variables
  public void init() throws ServletException {
    //Get the intial context to look up the DataSource
    Context ctx = null;
    Hashtable env = new Hashtable();
    env.put(Context.INITIAL_CONTEXT_FACTORY, "weblogic.jndi.WLInitialContextFactory");

    try {
      //Get the 2 DataSources for NonStop SQL/MX and PointBase - can throw NamingException
      ctx = new InitialContext(env);
      mxDS = (javax.sql.DataSource)ctx.lookup("TwoPhaseDS-SqlMx");
      mxConn = mxDS.getConnection();
      selMx = mxConn.prepareStatement("select author, title from books where subject=?");
    }
    catch (NamingException ne) {
      StringWriter sw = new StringWriter();
      sw.write("Naming Exception. Failed to look up TwoPhaseDS-SqlMxDataSource...\n");
      sw.write(ne.toString());
      PrintWriter out = new PrintWriter(sw);
      ne.printStackTrace(out);
      out.flush();
      FileLogger.writeToLog(Level.SEVERE, sw.toString());
      throw new ServletException(sw.toString());
    }
    catch (SQLException sqle) {
      StringWriter sw = new StringWriter();
      sw.write("SQL Exception. Failed to connect to NonStop SQL/MX Database...\n");
      sw.write(sqle.toString());
      PrintWriter out = new PrintWriter(sw);
      sqle.printStackTrace(out);
      out.flush();
      FileLogger.writeToLog(Level.SEVERE, sw.toString());
      throw new ServletException(sw.toString());
    }
  }


  //Process the HTTP Get request
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();
    out.println("<html>");
    out.println("<head><title>Servlet2</title></head>");
    out.println("<body bgcolor=\"#ffffff\">");
    out.println("<p>The servlet has received a GET. This is the reply.</p>");
    out.println("</body></html>");
  }

  //Process the HTTP Post request
  public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    String subject = request.getParameter("Subject");
    String temp1, temp2, currId="";
    StringBuffer connDialogId = new StringBuffer();
    ResultSet rs;
    int i=0, j=0, dialogId=0;
    boolean noRows = true;
    com.tandem.t4jdbc.SQLMXConnection sqlMxConn=null;

    try {
      //Just open and close database connection 5 times and process to show connection pooling
      for (j=0; j<5; j++) {
        // mxConn = mxDS.getConnection();
        mxConn = mxDS.getConnection();

        //Write the connection dialogId to file
        StringBuffer connLogMsg = new StringBuffer();
        java.util.Date currDate = new java.util.Date();
        connLogMsg.append(currDate.toString());
        connLogMsg.append(" Subject: ");
        connLogMsg.append(subject);
        connLogMsg.append("  ***** Connection Id to NonStop SQL/MX database: ");
        sqlMxConn = (com.tandem.t4jdbc.SQLMXConnection) ((weblogic.jdbc.extensions.WLConnection)mxConn).getVendorConnection();
        dialogId = sqlMxConn.getDialogueId();
        currId = new Integer(dialogId).toString();
        connLogMsg.append(currId);
        FileLogger.writeToLog(Level.INFO, connLogMsg.toString());
        connLogMsg = null;
        connDialogId.append(currId);
        if (j < 4 ) {
          connDialogId.append(",  ");
        }

        selMx.setString(1, subject);
        rs = selMx.executeQuery();

        //Get all the authors and books
        i = 0;
        noRows = true;
        while (rs.next()) {
           noRows = false;
           temp1 = rs.getString(1);   // author
           request.setAttribute(authors[i], temp1);
           temp2 = rs.getString(2);
           request.setAttribute(titles[i], temp2);
           i = i+1;
         }

         if (noRows) {
           for (i=0; i < 5; i++) {
             request.setAttribute(authors[i], "");
             request.setAttribute(titles[i], "");
           }
         }

         rs.close();
         mxConn.close();
         if (j<4) {
           for (i=0; i<5; i++) {
             request.removeAttribute(authors[i]);
             request.removeAttribute(titles[i]);
           }
         }
      }

      //Forward the response
      request.setAttribute("Connection", connDialogId);
      getServletConfig().getServletContext().getRequestDispatcher("/Books.jsp").forward(request, response);
    }
    catch (SQLException sqle) {
      for (i=0; i<5; i++) {
          request.setAttribute(authors[i], "");
          request.setAttribute(titles[i], "");
      }
      StringWriter sw = new StringWriter();
      sw.write("SQL Exception. Error accessing the database...\n");
      PrintWriter out = new PrintWriter(sw);
      sqle.printStackTrace(out);
      out.flush();
      FileLogger.writeToLog(Level.SEVERE, sw.toString());
      request.setAttribute("Connection"," Database access error");
      getServletConfig().getServletContext().getRequestDispatcher("/Books.jsp").forward(request, response);
    }
  }


  //Clean up resources
  public void destroy() {
    try {
      mxConn.close();
    }
    catch(SQLException sqle) {
      //No-op since the servlet is being destroyed anyway
    }
  }
}
