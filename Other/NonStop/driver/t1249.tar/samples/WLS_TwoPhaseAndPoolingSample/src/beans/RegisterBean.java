// @ @ @ START COPYRIGHT @ @ @
//
// Copyright 2004
// Hewlett-Packard Development Company, L.P.
// Protected as an unpublished work.
// All rights reserved.
//
// The computer program listings, specifications and
// documentation herein are the property of Compaq Computer
// Corporation and successor entities such as Hewlett-Packard
// Development Company, L.P., or a third party supplier and
// shall not be reproduced, copied, disclosed, or used in whole
// or in part for any reason without the prior express written
// permission of Hewlett-Packard Development Company, L.P.
//
// @ @ @ END COPYRIGHT @ @ @

//
// You are granted a limited copyright to modify and use this sample
// code for your internal purposes only. THIS SOFTWARE IS PROVIDED "AS-
// IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
// NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
// PARTICULAR PURPOSE OR NONINFRINGEMENT. IN NO EVENT SHALL THE
// HEWLETT-PACKARD COMPANY OR ITS SUBSIDIARIES BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT
// OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
// SOFTWARE INCURRED BY YOU OR ANY THIRD PARTY IN CONNECTION WITH THE
// USE OF THIS SOFTWARE.
//


package regbeans;

import java.util.*;
import java.io.Serializable;

public class RegisterBean implements Serializable {
  private String firstName;
  private String email;
  private String password;
  private String zip;
  private String address1;
  private String address2;
  private String city;
  private String license;
  private String phone;
  private String lastName;
  private Hashtable errors;

  public RegisterBean() {
    firstName="";
    email="";
    password="";
    city="";
    zip="";
    phone="";
    address1="";
    address2="";
    lastName="";
    license="";
    errors = new Hashtable();
  }


  public boolean validate() {

    boolean allOk=true;

   /* if (firstName.length() == 0) {
      errors.put("fName","Please enter your first name");
      firstName="";
      allOk=false;
    }

    if (lastName.length() == 0) {
      errors.put("lName","Please enter your last name");
      lastName="";
      allOk=false;
    }*/

    if ((email.length() == 0) || (email.indexOf('@') == -1)) {
      errors.put("email","Please enter a valid email address");
      email="";
      allOk=false;
    }

    if (password.length() == 0 ) {
      errors.put("password","Please enter a valid password");
      password="";
      allOk=false;
    }

    if (zip.length() !=5 ) {
      errors.put("zip","Please enter a valid zip code");
      zip="";
      allOk=false;
    } else {
      try {
        int x = Integer.parseInt(zip);
      } catch (NumberFormatException e) {
        errors.put("zip","Please enter a valid zip code");
        zip="";
        allOk=false;
      }
    }

   // if (dLicense.length() == 0) {
   //   errors.put("dLicense","Please enter your Driving License number");
   //   dLicense="";
   //   allOk=false;
   // }

    if (phone.length() < 10) {
      errors.put("phone","Please enter your phone number");
      phone="";
      allOk=false;
    }

    return allOk;
  }

  public String getErrorMsg(String s) {
    String errorMsg =(String)errors.get(s);
    System.out.println(errorMsg);
    return (errorMsg == null) ? "":errorMsg;
  }

  public String getFirstName() {
    return firstName;
  }

  public String getLastName() {
    return lastName;
  }

  public String getEmail() {
    return email;
  }

  public String getPassword() {
    return password;
  }

  public String getZip() {
    return zip;
  }

  public String getCity() {
    return city;
  }

  public String getPhone() {
    return phone;
  }

  public String getLicense() {
    return license;
  }

  public String getAddress1() {
    return address1;
  }

  public String getAddress2() {
    return address2;
  }

  public void setEmail(String eml) {
    email=eml;
  }

  public void  setPassword(String p1) {
    password=p1;
  }

  public void setFirstName(String fName) {
    firstName = fName;
  }

  public void setLastName(String lName) {
    lastName = lName;
  }

  public void setAddress1(String addr1) {
    address1 = addr1;
  }

  public void setPhone(String ph) {
    phone = ph;
  }

  public void setAddress2(String addr2) {
    address2 = addr2;
  }

  public void setdLicense(String lic) {
    license = lic;
  }

  public void setCity(String cty) {
    city = cty;
  }

  public void setZip(String z) {
    zip=z;
  }

   public void setErrors(String name, String value) {
    errors.put(name, value);
   }

}

