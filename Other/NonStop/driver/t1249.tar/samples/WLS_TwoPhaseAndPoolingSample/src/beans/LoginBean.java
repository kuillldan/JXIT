// @ @ @ START COPYRIGHT @ @ @
//
// Copyright 2004
// Hewlett-Packard Development Company, L.P.
// Protected as an unpublished work.
// All rights reserved.
//
// The computer program listings, specifications and
// documentation herein are the property of Compaq Computer
// Corporation and successor entities such as Hewlett-Packard
// Development Company, L.P., or a third party supplier and
// shall not be reproduced, copied, disclosed, or used in whole
// or in part for any reason without the prior express written
// permission of Hewlett-Packard Development Company, L.P.
//
// @ @ @ END COPYRIGHT @ @ @

//
// You are granted a limited copyright to modify and use this sample
// code for your internal purposes only. THIS SOFTWARE IS PROVIDED "AS-
// IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
// NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
// PARTICULAR PURPOSE OR NONINFRINGEMENT. IN NO EVENT SHALL THE
// HEWLETT-PACKARD COMPANY OR ITS SUBSIDIARIES BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT
// OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
// SOFTWARE INCURRED BY YOU OR ANY THIRD PARTY IN CONNECTION WITH THE
// USE OF THIS SOFTWARE.
//


package regbeans;

import java.util.*;
import java.io.Serializable;

public class LoginBean implements Serializable {
  private String userID;
  private String pwd;
  private Hashtable errors;

  public LoginBean() {
    userID="";
    pwd="";
    errors = new Hashtable();
  }

  public boolean validate() {
    boolean allOk=true;
    if ((userID.length() == 0) || (userID.indexOf('@') == -1)) {
      errors.put("userID","Please enter a valid userID");
      userID="";
      allOk=false;
    }

    if (pwd.length() == 0 ) {
      errors.put("pwd","Please enter a valid password");
      pwd="";
      allOk=false;
    }
    return allOk;
  }

  public String getErrorMsg(String s) {
    String errorMsg =(String)errors.get(s);
    return (errorMsg == null) ? "":errorMsg;
  }

  public String getUserID() {
    return userID;
  }

  public String getPwd() {
    return pwd;
  }


  public void setUserID(String uid) {
    userID=uid;
  }

  public void setPwd(String password) {
    pwd=password;
  }


  public void setErrors(String name, String value) {
    errors.put(name, value);
  }

}

