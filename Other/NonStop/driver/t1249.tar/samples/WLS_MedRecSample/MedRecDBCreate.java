import common.*;
import java.sql.*;

public class MedRecDBCreate
{
    public static void main(String args[])
    {

    Connection          connection;
    Statement           stmt;
    String              catalogSchema;

    try {
      String catalogName="", catalogVol="", schemaName="" ;

      //get the args
      for (int i = 0; i < args.length; i++) {
        if (args[i].equals("-c")){
          catalogName = args[++i];
        }
        else if (args[i].equals("-v")){
          catalogVol = args[++i];
        }
        else if (args[i].equals("-s")){
          schemaName = args[++i];
        }
        else {
          System.out.println();
          System.out.println("Usage: MedRecDBCreate [-c <valid NonStop SQL/MX catalog-name>] [-v <valid NSK volume>] [-s <valid NonStop SQL/MX schema-name>]");
          System.out.println();
          System.out.println("Example:  MedRecDBCreate -c wls_sample -v $DATA01 -s medrec");
          System.exit(-1);
        }
      }

      //Set the defaults if no command line args are given
      if (0 == catalogName.length()){
        catalogName = "wls_sample";
      }

      if (0 == schemaName.length()){
        schemaName = "medrec";
      }

      catalogSchema = catalogName + "." + schemaName;

      //Create the MedRec database.
      //First create the catalog wls_sample and schema medrec.
      connection = sampleUtils.getUserConnection();
      stmt = connection.createStatement();
      System.out.println();
      System.out.println("Creating catalog " + catalogName + "....");
      if (0 == catalogVol.length()) {
       stmt.executeUpdate("create catalog " + catalogName);
      }
      else {
       stmt.executeUpdate("create catalog " + catalogName + " location " + catalogVol);
      }

      System.out.println();
      System.out.println("Creating schema " + schemaName + "....");
      stmt.executeUpdate("create schema " + catalogSchema);

      System.out.println();
      System.out.println("Creating the Medrec database " );
      System.out.println("**************************************************** " );

      //Create the MedRec tables
      System.out.println();
      System.out.println("Creating table address ... " );
      stmt.executeUpdate("CREATE TABLE " + catalogSchema + ".address  ( " +
                         "id        NUMERIC (9) UNSIGNED NO DEFAULT NOT NULL NOT DROPPABLE" +
                         ",street1  VARCHAR (60) NOT NULL NOT DROPPABLE" +
                         ",street2  VARCHAR(60) DEFAULT NULL" +
                         ",city     VARCHAR(60) NOT NULL NOT DROPPABLE" +
                         ",state    VARCHAR(2) NOT NULL NOT DROPPABLE" +
                         ",zip      VARCHAR(10) NOT NULL NOT DROPPABLE" +
                         ",country  VARCHAR(50) NOT NULL NOT DROPPABLE" +
                         ",PRIMARY KEY  (id) NOT DROPPABLE)");

      System.out.println();
      System.out.println("Creating table address_seq ... " );
      stmt.executeUpdate("CREATE TABLE " + catalogSchema + ".address_seq(sequence  NUMERIC (9) UNSIGNED DEFAULT NULL )");

      System.out.println();
      System.out.println("Creating table groups... " );
      stmt.executeUpdate("CREATE TABLE " + catalogSchema + ".groups (" +
                         "username VARCHAR(60) NO DEFAULT NOT NULL NOT DROPPABLE" +
                         ",group_name VARCHAR (60) NOT NULL NOT DROPPABLE)");


      System.out.println();
      System.out.println("Creating table medrec_user... " );
      stmt.executeUpdate("CREATE TABLE " + catalogSchema + ".medrec_user (" +
                          "username VARCHAR(45) NO DEFAULT NOT NULL NOT DROPPABLE" +
                          ",password VARCHAR (10) NOT NULL NOT DROPPABLE" +
                          ",status VARCHAR (15) NOT NULL NOT DROPPABLE" +
                          ",PRIMARY KEY (username) NOT DROPPABLE)");



      System.out.println();
      System.out.println("Creating table patient... " );
      stmt.executeUpdate("CREATE TABLE " + catalogSchema + ".patient (" +
                          "id  NUMERIC (9) UNSIGNED NO DEFAULT NOT NULL NOT DROPPABLE" +
                          ",first_name  VARCHAR (60) NOT NULL NOT DROPPABLE" +
                          ",middle_name VARCHAR(60) DEFAULT NULL" +
                          ",last_name   VARCHAR(60) NOT NULL NOT DROPPABLE" +
                          ",dob DATE NOT NULL NOT DROPPABLE" +
                          ",gender  VARCHAR(6) NOT NULL NOT DROPPABLE" +
                          ",ssn  VARCHAR(9) NOT NULL NOT DROPPABLE" +
                          ",address_id  NUMERIC (9) UNSIGNED NOT NULL NOT DROPPABLE" +
                          ",phone  VARCHAR(15) DEFAULT NULL" +
                          ",email  VARCHAR(60) NOT NULL NOT DROPPABLE" +
                          ",PRIMARY KEY  (id) NOT DROPPABLE )");


      System.out.println();
      System.out.println("Creating table patient_seq... " );
      stmt.executeUpdate("CREATE TABLE " + catalogSchema + ".patient_seq(sequence  NUMERIC (9) UNSIGNED DEFAULT NULL )");

      System.out.println();
      System.out.println("Creating table physician... " );
      stmt.executeUpdate("CREATE TABLE " + catalogSchema + ".physician (" +
                          "id   NUMERIC (9) UNSIGNED NO DEFAULT NOT NULL NOT DROPPABLE" +
                          ",first_name  VARCHAR (60) NOT NULL NOT DROPPABLE" +
                          ",middle_name VARCHAR(60) DEFAULT NULL" +
                          ",last_name   VARCHAR (60) NOT NULL NOT DROPPABLE" +
                          ",address_id  NUMERIC (9) UNSIGNED NOT NULL NOT DROPPABLE" +
                          ",phone VARCHAR(15) DEFAULT NULL" +
                          ",email VARCHAR(60) DEFAULT NULL" +
                          ",PRIMARY KEY  (id) NOT DROPPABLE)");


      System.out.println();
      System.out.println("Creating table physician_seq... " );
      stmt.executeUpdate("CREATE TABLE " + catalogSchema + ".physician_seq(sequence  NUMERIC (9) UNSIGNED DEFAULT NULL )");

      System.out.println();
      System.out.println("Creating table prescription... " );
      stmt.executeUpdate("CREATE TABLE " + catalogSchema + ".prescription (" +
                          "id  NUMERIC (9) UNSIGNED NO DEFAULT NOT NULL NOT DROPPABLE" +
                          ",pat_id  NUMERIC (9) UNSIGNED NO DEFAULT NOT NULL NOT DROPPABLE" +
                          ",issuing_phys_id   NUMERIC (9) UNSIGNED NO DEFAULT NOT NULL NOT DROPPABLE" +
                          ",date_prescribed   DATE NOT NULL NOT DROPPABLE" +
                          ",drug VARCHAR (80) NOT NULL NOT DROPPABLE" +
                          ",record_id  NUMERIC (9) UNSIGNED NOT NULL NOT DROPPABLE" +
                          ",dosage VARCHAR(30) NOT NULL NOT DROPPABLE" +
                          ",frequency VARCHAR(30) NOT NULL NOT DROPPABLE" +
                          ",refills_remaining NUMERIC (9) UNSIGNED DEFAULT NULL" +
                          ",instructions VARCHAR(255) DEFAULT NULL" +
                          ",PRIMARY KEY  (id) NOT DROPPABLE)");


      System.out.println();
      System.out.println("Creating table prescription_seq... " );
      stmt.executeUpdate("CREATE TABLE " + catalogSchema + ".prescription_seq(sequence  NUMERIC (9) UNSIGNED DEFAULT NULL )");

      System.out.println();
      System.out.println("Creating table record... " );
      stmt.executeUpdate("CREATE TABLE " + catalogSchema + ".record (" +
                          "id  NUMERIC (9) UNSIGNED NO DEFAULT NOT NULL NOT DROPPABLE" +
                          ",pat_id NUMERIC (9) UNSIGNED  NO DEFAULT NOT NULL NOT DROPPABLE" +
                          ",phys_id  NUMERIC (9) UNSIGNED NO DEFAULT NOT NULL NOT DROPPABLE" +
                          ",record_date  DATE NOT NULL NOT DROPPABLE" +
                          ",vital_id  NUMERIC (9) UNSIGNED NOT NULL NOT DROPPABLE" +
                          ",symptoms VARCHAR(255) NOT NULL NOT DROPPABLE" +
                          ",diagnosis  VARCHAR(255) DEFAULT NULL" +
                          ",notes VARCHAR(255) DEFAULT NULL" +
                          ",PRIMARY KEY  (id) NOT DROPPABLE)");

      System.out.println();
      System.out.println("Creating table record_seq... " );
      stmt.executeUpdate("CREATE TABLE " + catalogSchema + ".record_seq(sequence  NUMERIC (9) UNSIGNED DEFAULT NULL )");


      System.out.println();
      System.out.println("Creating table vital_signs... " );
      stmt.executeUpdate("CREATE TABLE " + catalogSchema + ".vital_signs (" +
                          "id  NUMERIC (9) UNSIGNED  NO DEFAULT NOT NULL NOT DROPPABLE" +
                          ",temperature VARCHAR(4)  NOT NULL NOT DROPPABLE" +
                          ",blood_pressure  VARCHAR(10) DEFAULT NULL" +
                          ",pulse VARCHAR(10) DEFAULT NULL" +
                          ",weight NUMERIC (9) UNSIGNED DEFAULT NULL" +
                          ",height  NUMERIC (9) UNSIGNED DEFAULT NULL" +
                          ",PRIMARY KEY  (id) NOT DROPPABLE)");

      System.out.println("");
      System.out.println("Creating table vital_signs_seq... " );
      stmt.executeUpdate("CREATE TABLE " + catalogSchema + ".vital_signs_seq(sequence  NUMERIC (9) UNSIGNED DEFAULT NULL )");


      //Insert data into the tables created.
      System.out.println();
      System.out.println("Inserting data into address table... " );
      stmt.executeUpdate("insert into " + catalogSchema + ".address" + " values(101,'1224 Post St','Suite 100','San Francisco','CA','94115','United States')");
      stmt.executeUpdate("insert into " + catalogSchema + ".address" + " values(102,'235 Montgomery St','Suite 15','Ponte Verde','FL','32301','United States')");
      stmt.executeUpdate("insert into " + catalogSchema + ".address" + " values(103,'1234 Market','','San Diego','CA','92126','United States')");

      System.out.println();
      System.out.println("Inserting data into address_seq table... " );
      stmt.executeUpdate("insert into " + catalogSchema + ".address_seq" + " values(6080)");

      System.out.println();
      System.out.println("Inserting data into groups table... " );
      stmt.executeUpdate("insert into " + catalogSchema + ".groups" + " values('fred@pga.com','MedRecPatients')");
      stmt.executeUpdate("insert into " + catalogSchema + ".groups" + " values('larry@celtics.com','MedRecPatients')");
      stmt.executeUpdate("insert into " + catalogSchema + ".groups" + " values('charlie@heisman.com','MedRecPatients')");
      stmt.executeUpdate("insert into " + catalogSchema + ".groups" + " values('volley@ball.com','MedRecPatients')");
      stmt.executeUpdate("insert into " + catalogSchema + ".groups" + " values('page@vidablue.com','MedRecPatients')");

      System.out.println();
      System.out.println("Inserting data into medrec_user table... " );
      stmt.executeUpdate("insert into " + catalogSchema + ".medrec_user" + " values('volley@ball.com','weblogic','ACTIVE')");
      stmt.executeUpdate("insert into " + catalogSchema + ".medrec_user" + " values('page@vidablue.com','weblogic','ACTIVE')");
      stmt.executeUpdate("insert into " + catalogSchema + ".medrec_user" + " values('charlie@heisman.com','weblogic','NEW')");
      stmt.executeUpdate("insert into " + catalogSchema + ".medrec_user" + " values('fred@pga.com','weblogic','ACTIVE')");
      stmt.executeUpdate("insert into " + catalogSchema + ".medrec_user" + " values('larry@celtics.com','weblogic','ACTIVE')");

      System.out.println();
      System.out.println("Inserting data into patient table... " );
      stmt.executeUpdate("insert into " + catalogSchema + ".patient" + " values(101,'Fred','I','Couples', DATE '1965-03-26','Male','123456789',101,'4151234564','fred@pga.com')");
      stmt.executeUpdate("insert into " + catalogSchema + ".patient" + " values(102,'Larry','J','Bird',DATE '1959-02-13','Male','777777777',101,'4151234564','larry@celtics.com')");
      stmt.executeUpdate("insert into " + catalogSchema + ".patient" + " values(103,'Charlie','E','Ward',DATE '1973-10-29','Male','444444444',102,'4151234564','charlie@heisman.com')");
      stmt.executeUpdate("insert into " + catalogSchema + ".patient" + " values(104,'Gabrielle','H','Reese',DATE '1971-08-17','Female','333333333',101,'4151234564','volley@ball.com')");
      stmt.executeUpdate("insert into " + catalogSchema + ".patient" + " values(105,'Page','A','McConnel',DATE '1972-02-18','Male','888888888',102,'4151234564','page@vidablue.com')");

      System.out.println();
      System.out.println("Inserting data into patient_seq table... " );
      stmt.executeUpdate("insert into " + catalogSchema + ".patient_seq" + " values(7140)");

      System.out.println();
      System.out.println("Inserting data into physician table... " );
      stmt.executeUpdate("insert into " + catalogSchema + ".physician" + " values(101,'Mary','J','Joplin',102,'1234567812','maryj@dr.com')");
      stmt.executeUpdate("insert into " + catalogSchema + ".physician" + " values(102,'Phil','B','Lance',102,'1234567812','phil@syscon.com')");
      stmt.executeUpdate("insert into " + catalogSchema + ".physician" + " values(103,'Kathy','E','Wilson',102,'1234567812','kwilson@dr.com')");

      System.out.println();
      System.out.println("Inserting data into physician_seq table... " );
      stmt.executeUpdate("insert into " + catalogSchema + ".physician_seq" + " values(110)");

      System.out.println();
      System.out.println("Inserting data into prescription table... " );
      stmt.executeUpdate("insert into " + catalogSchema + ".prescription" + " values(101,101,102,DATE '1999-06-18','Advil',101,'100 tbls','1/4hrs',0,'No instructions')");
      stmt.executeUpdate("insert into " + catalogSchema + ".prescription" + " values(102,101,102,DATE '1999-06-18','Drixoral',101,'16 oz','1tspn/4hrs',0,'No instructions')");
      stmt.executeUpdate("insert into " + catalogSchema + ".prescription" + " values(103,101,102,DATE '1993-05-30','Codiene',102,'10 oz','1/6hrs',1,'No instructions')");
      stmt.executeUpdate("insert into " + catalogSchema + ".prescription" + " values(104,102,102,DATE '2001-06-20','Valium',108,'50 pills','1/day',3,'No instructions')");

      System.out.println();
      System.out.println("Inserting data into prescription_seq table... " );
      stmt.executeUpdate("insert into " + catalogSchema + ".prescription_seq" + " values(110)");

      System.out.println();
      System.out.println("Inserting data into record table... " );
      stmt.executeUpdate("insert into " + catalogSchema + ".record" + " values(101,101,102,DATE '1999-06-18',101,'Complains about chest pain.','Mild stroke.  Aspiran advised.','Patient needs to stop smoking.')");
      stmt.executeUpdate("insert into " + catalogSchema + ".record" + " values(102,101,102,DATE '1993-05-30',101,'Sneezing, coughing, stuffy head.','Common cold. Prescribed codiene cough syrup.','Call back if not better in 10 days.')");
      stmt.executeUpdate("insert into " + catalogSchema + ".record" + " values(103,101,102,DATE '1989-07-05',101,'Twisted knee while playing soccer.','Severely sprained interior ligament.  Surgery required.','Cast will be necessary before and after.')");
      stmt.executeUpdate("insert into " + catalogSchema + ".record" + " values(104,103,103,DATE '2000-02-18',102,'Ya ya ya.','Blah, Blah, Blah.','Notes start here.')");
      stmt.executeUpdate("insert into " + catalogSchema + ".record" + " values(105,105,101,DATE '1991-04-01',103,'Drowsy all day.','Allergic to coffee.  Drink tea.','No notes.')");
      stmt.executeUpdate("insert into " + catalogSchema + ".record" + " values(106,105,101,DATE '1987-01-13',101,'Blurred vision.','Increased loss of vision due to recent car accident.','Admit patient to hospital.')");
      stmt.executeUpdate("insert into " + catalogSchema + ".record" + " values(107,105,101,DATE '1990-09-09',102,'Sore throat.','Strep thoart culture taken.  Sleep needed.','Call if positive.')");
      stmt.executeUpdate("insert into " + catalogSchema + ".record" + " values(108,102,102,DATE '2001-06-20',101,'Overjoyed with everything.','Patient is crazy.  Recommend politics.','')");
      stmt.executeUpdate("insert into " + catalogSchema + ".record" + " values(109,104,103,DATE '2002-11-03',101,'Sprained ankle.','Lite cast needed.','At least 20 sprained ankles since 15.')");
      stmt.executeUpdate("insert into " + catalogSchema + ".record" + " values(110,103,103,DATE '1997-12-21',101,'Forgetful, short-term memory not as sharpe.','General old age.','Patient will someday be 120 years old.')");
      stmt.executeUpdate("insert into " + catalogSchema + ".record" + " values(111,104,102,DATE '2001-05-13',101,'Nothing is wrong.','This gal is fine.','Patient likes lobby magazines.')");

      System.out.println();
      System.out.println("Inserting data into record_seq table... " );
      stmt.executeUpdate("insert into " + catalogSchema + ".record_seq" + " values(110)");

      System.out.println();
      System.out.println("Inserting data into vital_signs table... " );
      stmt.executeUpdate("insert into " + catalogSchema + ".vital_signs" + " values(101,'98','125/85','75',180,70)");
      stmt.executeUpdate("insert into " + catalogSchema + ".vital_signs" + " values(102,'100','120/80','85',199,69)");
      stmt.executeUpdate("insert into " + catalogSchema + ".vital_signs" + " values(103,'98','110/75','95',300,76)");

      System.out.println();
      System.out.println("Inserting data into vital_signs_seq table... " );
      stmt.executeUpdate("insert into " + catalogSchema + ".vital_signs_seq" + " values(110)");

      System.out.println();
      System.out.println("**************************************************** " );
      System.out.println("Created the MedRec database and inserted data");

      stmt.close();
      connection.close();
    }
    catch (SQLException e)
    {
        SQLException nextException;

        nextException = e;
        do
        {
            System.out.println(nextException.getMessage());
            System.out.println("SQLState   " + nextException.getSQLState());
            System.out.println("Error Code " + nextException.getErrorCode());
        } while ((nextException = nextException.getNextException()) != null);
    }
    }
}
