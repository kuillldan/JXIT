import common.*;

import java.sql.*;
public class CallableStatementSample
{
    public static void main(String args[]) throws Exception
    {
        try
        {
            Connection conn = sampleUtils.getPropertiesConnection();
            Statement stmt = conn.createStatement();

            try
            {
              String st = "drop procedure CallableStatementSample";
              try {
              stmt.executeUpdate(st);
              } catch (Exception e) {}

              st = "create procedure CallableStatementSample(out OUT_PARAM INTEGER) EXTERNAL NAME 'IntegerSPJ.Integer_Proc(int[])' EXTERNAL PATH '/tmp' LANGUAGE JAVA PARAMETER STYLE JAVA CONTAINS SQL NO ISOLATE";
              stmt.executeUpdate(st);
              stmt.close();
            }
            catch (SQLException e)
            {
              e.printStackTrace();
              System.exit(0);
            }


            // get the CallableStatement object
            CallableStatement cstmt = conn.prepareCall("{call CallableStatementSample(?)}");
            System.out.println("The Callable Statement " + cstmt);

            //register the output parameters
            cstmt.registerOutParameter(1, java.sql.Types.VARCHAR);

            //execute the procedure
            cstmt.execute();

            //invoke getInt method
            int nRetVal = cstmt.getInt(1);

            System.out.println("Out parameter is " + cstmt.getInt(1));
        }
        catch(Exception ex)
        {
            System.err.println("Unexpected Exception" + ex.getMessage());
            throw new Exception("Call to getWarnings is Failed!");
        }
    }
}
