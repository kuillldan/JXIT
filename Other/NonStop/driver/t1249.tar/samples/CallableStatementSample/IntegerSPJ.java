public class IntegerSPJ
{
    public static void Integer_Proc (int[] out_param)
    {

        out_param[0] = 100;
    }
}
