package bitool.enums;

public enum UserType
{
	ADMIN,NORMAL
}
