package bitool.enums;

public enum OpenOffStatus
{
	OPEN,CLOSED,ADMIN_OPEN
}
