package bitool.enums;

public enum OpenOffMode
{
	MANUAL,AUTO,MAINTAINANCE
}
